import { Component, OnInit } from '@angular/core';
import { Programa } from './programa';
import { ProgramaService } from './programa.service';


@Component({
  selector: 'app-programa',
  templateUrl: './programa.component.html',
  styleUrls: ['./programa.component.css']
})
export class ProgramaComponent implements OnInit {
titulo:string="Lista de Programas";

  programas:Programa[];

  constructor(private pservice:ProgramaService) { }

  ngOnInit(): void {
    this.pservice.getAll().subscribe(
          p  => this.programas=p
    );
  }

}
