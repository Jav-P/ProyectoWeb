export class Programa{
    num_programa:String;
    nombre:String;
    facultad:String;
    escuela:String;
}
